# -*- coding: utf-8 -*-
"""
Created on Wed May 17 22:24:25 2023

@author: Tejas
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import statsmodels.api as sm
from scipy.stats import linregress, chi2_contingency

loan_data = pd.read_csv("hmeq.csv")
print("Loan data shape:", loan_data.shape)
loan_data.head()

# Correlation matrix to identify multicollinearity among numerical variables
corr_matrix = loan_data.corr()
numeric_data = loan_data[['BAD', 'LOAN', 'MORTDUE', 'VALUE', 'YOJ', 'DELINQ', 'NINQ']]

# Pair plot for numeric variables
sns.pairplot(numeric_data, kind="scatter")
plt.show()

# Scatter plot b/t 'BAD' and 'LOAN'
plt.scatter(loan_data['BAD'], loan_data['LOAN'])
plt.show()

# Correlation coefficient b/t 'BAD' and 'LOAN'
corr_coeff = np.corrcoef(loan_data['BAD'], loan_data['LOAN'])
print("Correlation coefficient between 'BAD' and 'LOAN':", corr_coeff)

# Missing values in 'BAD' and 'LOAN' columns
print("Number of missing values in 'BAD' column:", loan_data['BAD'].isnull().sum())
print("Number of missing values in 'LOAN' column:", loan_data['LOAN'].isnull().sum())

# Linear regression b/t 'BAD' and 'LOAN'
regression_result = linregress(loan_data['BAD'], loan_data['LOAN'])
print("Linear regression result between 'BAD' and 'LOAN':", regression_result)

# Contingency table and perform chi-square test b/t 'BAD' and 'MORTDUE'
contingency_table = pd.crosstab(loan_data.BAD, loan_data.MORTDUE)
chi2_result = chi2_contingency(contingency_table)
print("Chi-square test result between 'BAD' and 'MORTDUE':", chi2_result)

# Analyze loan data and identify risk factors
def analyze_loan_data(data):
    default_rates = data.groupby('LOAN')['BAD'].mean()
    risk_levels = pd.cut(default_rates, bins=[0, 0.1, 0.2, 1], labels=['Low Risk', 'Medium Risk', 'High Risk'])
    data['Risk_Level'] = data['LOAN'].map(risk_levels)
    return data

analyzed_data = analyze_loan_data(loan_data)

# Risk level recommendations based on the analysis results
risk_recommendations = []
for level in analyzed_data['Risk_Level']:
    if level == 'Low Risk':
        risk_recommendations.append('Approved')
    elif level == 'Medium Risk':
        risk_recommendations.append('Conditional Approval')
    else:
        risk_recommendations.append('Rejected')
analyzed_data['Risk_Recommendation'] = risk_recommendations

# New CSV file for results
analyzed_data.to_csv('loan_data_analysis_results.csv', index=False)

print('------- Loan Data Analysis Results -------')
print('Total number of loans:', len(analyzed_data))
print('Number of loans in each risk category:')
print(analyzed_data['Risk_Level'].value_counts())
print('Risk level recommendations for each loan:')
print(analyzed_data[['LOAN', 'Risk_Level', 'Risk_Recommendation']])