Name: Tejas Gokarn
Class: EE104 Section 01

GitHub Link: https://github.com/TexasGokart/EE104-Lab-9 

----------[(Risk Factor Identification)]----------

***REQUIRED PYTHON LIBRARIES***
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import statsmodels.api as sm
from scipy.stats import linregress, chi2_contingency

***ABOUT THIS CODE***
This code reads loan data from a CSV file, performs an analysis on the data to identify risk factors, and adds additional columns to the loan data indicating the risk level and risk recommendations for each loan. The analysis calculates the default rate for each loan type, categorizes the risk level based on the default rate, and assigns risk level recommendations. The results are then written to a new CSV file, and a summary of the analysis results and risk recommendations is printed.



----------[(Trend Prediction)]----------

***REQUIRED PYTHON LIBRARIES***
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.statespace.sarimax import SARIMAX

***ABOUT THIS CODE***
This code analyzes a COVID-19 dataset using the SARIMAX model and makes predictions for the remaining months of the year. It combines the actual data with the predicted values and plots them to visualize the forecasted COVID-19 cases.



----------[(Dance Challenge Game)]----------

***REQUIRED PYTHON LIBRARIES***
import music
import time
from pgzero.builtins import Actor
import pgzrun
from random import randint

***ABOUT THIS CODE***
This code is a dancing game implemented using the Pygame Zero library. It allows two players to follow a sequence of dance moves displayed on the screen. Players score points by correctly matching the sequence of moves and the game ends when one of the players messes up the sequence. The game features a dancer character, arrow icons representing the dance moves, and a custom song from the internet. Player 1 uses the arrow keys to play and Player 2 uses WASD, with the game switching between the two players every time one correctly matches their move sequence.